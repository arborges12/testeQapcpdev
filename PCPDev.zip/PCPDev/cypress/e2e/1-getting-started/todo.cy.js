/// <reference types="cypress" />

describe('Acessar Site', () => {
  beforeEach(() => {
    cy.visit('https://www.pcpdev.com.br/')
    cy.get('#onetrust-accept-btn-handler').click()
  })

  it('Validar campo objeto', () => {
    cy.get('#pesquisa-p > :nth-child(1) > label')
      .should('have.text', 'Objeto:')
  })

  it('Inserir texto no campo Objeto', () => {
    cy.get('#objeto')
      .type('Processo')
      .should('have.value', 'Processo')
  })

  it('Buscar processo campo objeto ', () => {
    cy.get('#objeto')
      .type('Processo').should('have.value', 'Processo')
    cy.get('.btn-pesquisa-p')
      .should('be.visible')
      .should('text', 'BUSCAR')
      .click()
  })

  it('Validar campo processo', () => {
    cy.get('#pesquisa-p')
      .find('[for="processo"]')
      .should('be.visible')
      .should('have.text', 'Processo:')
  })

  it('Buscar por Processo', () => {
    cy.get('#processo')      
      .type(20251111223)
      .should('have.value', '20251111223')
    cy.get('.btn-pesquisa-p')
      .click()
  })
  
  it('Validar campo Orgão', () => {
    cy.get('#pesquisa-p')
      .find('[for="orgao"]')
      .should('be.visible')
      .should('have.text', 'Órgão:')
  })
  it('Buscar por Orgão', () => {
    cy.get('#orgao')      
      .type('PUBLICO').should('have.value', 'PUBLICO')
    cy.get('.btn-pesquisa-p')
      .click()
  })
  it('Listar campos busca avançada', () => {
    cy.get('#pesquisa-p')
      .find('.busca-av').click()
    cy.get('#Status')
      .should('be.visible')
    cy.get('#Modalidade')
      .should('be.visible')
    cy.get('#Realizacao')
      .should('be.visible')
    cy.get('#julgamento')
      .should('be.visible')
    cy.get('.busca-av-block')
      .find('[for="periodo"]')
      .should('be.visible')
    cy.get('#UF')
      .should('be.visible')
    cy.get('#municipios')
      .should('be.visible')
  })
})
